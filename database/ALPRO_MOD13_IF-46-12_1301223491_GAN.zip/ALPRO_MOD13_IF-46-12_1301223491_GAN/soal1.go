package main

import "fmt"

type sale struct {
	d, m, y int
	sale    float64
}

type sales struct {
	data [30]sale
	size int
}

func (s *sales) getbydate(d, m, y int) float64 {
	var i = 0
	var found = false
	var sale float64 = -1
	for i = 0; i < s.size && !found; i++ {
		var cursale = s.data[i]
		if cursale.d == d && cursale.m == m && cursale.y == y {
			sale = cursale.sale
		}
	}

	return sale
}

func (s *sales) binsearchd(target int) float64 {
	var up, down, mid int
	var res float64
	var found bool = false
	up = s.size - 1
	down = 0
	res = -1

	var sales = s.data

	for down <= up && !found {
		mid = (up + down/2)
		if sales[mid].d == target {
			found = true
			res = sales[mid].sale
		} else if sales[mid].d < target {
			down = mid + 1
		} else {
			up = mid - 1
		}
	}

	return res
}

func (s *sales) getidxmax(from, until int) int {
	var sales = s.data
	var idxmax, i int
	var max float64
	max = sales[from].sale
	idxmax = from

	for i = from; i < until; i++ {
		if max < sales[i].sale {
			max = sales[i].sale
			idxmax = i
		}
	}

	return idxmax
}

func (s *sales) getidxmin(from, until int) int {
	var sales = s.data
	var idxmin, i int
	var min int
	min = sales[from].d
	idxmin = from

	for i = from; i < until; i++ {
		if min > sales[i].d {
			min = sales[i].d
			idxmin = i
		}
	}

	return idxmin
}

func (s *sales) sortbysaledesc() {
	var i = 0
	for i = 0; i < s.size; i++ {
		var max = s.getidxmax(i, s.size)
		s.data[i], s.data[max] = s.data[max], s.data[i]
	}
}

func (s *sales) sortbydateasc() {
	var i = 0
	for i = 0; i < s.size; i++ {
		var min = s.getidxmin(i, s.size)
		s.data[i], s.data[min] = s.data[min], s.data[i]
	}
}

func (s *sales) print() {
	var i = 0
	fmt.Println("")
	for i = 0; i < s.size; i++ {
		var cursale = s.data[i]
		fmt.Printf("%d\t%d\t%d\t%f\n", cursale.d, cursale.m, cursale.y, cursale.sale)
	}
	fmt.Println("")
}

func main() {
	var i = 0
	var sales = sales{}
	for i = 0; i < 30; i++ {
		fmt.Scan(&sales.data[i].d)
		fmt.Scan(&sales.data[i].m)
		fmt.Scan(&sales.data[i].y)
		fmt.Scan(&sales.data[i].sale)
		sales.size++
	}
	fmt.Printf("\nSearch result berdasar d,m,y %f\n\n", sales.getbydate(1, 5, 2023))

	sales.print()
	sales.sortbysaledesc()
	sales.print()

	sales.sortbydateasc()
	sales.print()
	fmt.Printf("\nSearch result berdasar d (binsearch) %f\n\n", sales.binsearchd(22))

}
