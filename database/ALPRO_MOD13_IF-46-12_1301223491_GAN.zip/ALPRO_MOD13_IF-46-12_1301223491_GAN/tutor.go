package main

import "fmt"
const nmax = 30

type person struct {
	name string
	birthyear int
}

type personarr struct {
	size int
	data [30]person
}

func(p *personarr) insert(per person) {
	p.data[p.size] = per
	p.size++
}

func max(a,b int) int {
	if a > b {
		return a
	} else {
		return b
	}

}

func(p *personarr) getminindex(from int, until int) (index int) {
	var min = p.data[from].birthyear
	var minindex = from

	for i := from; i < until; i++ {
		if p.data[i].birthyear < min {
			min = p.data[i].birthyear
			minindex = i
		}
	}

	return minindex
}

func(p *personarr) sort(){
	var i = 0;
	for i = 0; i < p.size; i++ {
		minidx := p.getminindex(i, p.size)
		p.data[i], p.data[minidx] = p.data[minidx], p.data[i]
	}
}

func(p *personarr) print(limit int){
	if limit == 0 {
		limit = p.size
	}
	for i := 0; i < p.size && i < limit; i++ {
		fmt.Printf("%s %d\n",  p.data[i].name, p.data[i].birthyear)
	}
}

func(p *personarr) getavg() int {
	var total,i int
	for i = 0; i < p.size; i++ {
		total += p.data[i].birthyear
	}

	return total / p.size
}



func main(){
	var people = personarr{}

	var person = person{}

	fmt.Scan(&person.name)

	for person.name != "#" {
		fmt.Scan(&person.birthyear)
		people.insert(person)


		fmt.Scan(&person.name)
		people.sort()
	}

	people.print(3)
	fmt.Println("Rata rata tahun lahir generasi Z adalah", people.getavg())
}
